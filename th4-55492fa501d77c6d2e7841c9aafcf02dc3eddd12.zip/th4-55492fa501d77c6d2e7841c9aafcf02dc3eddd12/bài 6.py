ds=input('Nhập tên:').split()
print(ds)
for so in ds:
    print(so)a