s=input("Nhập chuổi:").split()
s.sort()
print(s)