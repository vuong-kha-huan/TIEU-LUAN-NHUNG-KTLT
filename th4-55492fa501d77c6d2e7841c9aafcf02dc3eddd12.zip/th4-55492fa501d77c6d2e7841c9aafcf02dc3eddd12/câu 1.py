s = input('nhập chuổi :')
for x in s:
    print(x)
