s = input('nhập chuổi :').split()
for x in s:
    print(x)
