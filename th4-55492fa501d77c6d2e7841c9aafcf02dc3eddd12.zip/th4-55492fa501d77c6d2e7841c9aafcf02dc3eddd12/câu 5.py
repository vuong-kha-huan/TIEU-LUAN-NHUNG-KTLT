ds=input('danh sách:').split()
ds.reverse()
print(ds)
for so in ds:
    print(so)