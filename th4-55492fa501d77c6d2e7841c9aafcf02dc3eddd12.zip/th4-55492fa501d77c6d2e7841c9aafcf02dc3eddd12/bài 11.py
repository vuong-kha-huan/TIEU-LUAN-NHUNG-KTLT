ds=input("Nhập chuổi:").split()
ds.append('aaaa')
for ch in ds:
    print(ch)
