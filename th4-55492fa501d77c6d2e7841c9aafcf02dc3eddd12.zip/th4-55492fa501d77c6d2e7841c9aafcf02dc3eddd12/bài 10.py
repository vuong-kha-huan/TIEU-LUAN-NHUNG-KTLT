ds=input("Nhập chuổi:").split()
x=ds[1:-1]
for c in x:
    print(c)
