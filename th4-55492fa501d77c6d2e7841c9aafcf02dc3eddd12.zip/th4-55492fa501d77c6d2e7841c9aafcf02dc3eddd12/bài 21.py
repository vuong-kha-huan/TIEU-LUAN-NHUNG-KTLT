s=input("nhập chuổi nhị phân: ").split(',')
for i in s:
    if int(i,2)%5==0:
        print(i)


