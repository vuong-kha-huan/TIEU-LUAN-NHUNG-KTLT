ds=input("Nhập chuổi:").split()
print(" vị trí của chuổi A là ", ds.index('A'))
