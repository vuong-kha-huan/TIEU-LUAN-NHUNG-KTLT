ds=input("Nhập chuổi:").split()
ds.remove('123')
for ch in ds:
    print(ch)
    