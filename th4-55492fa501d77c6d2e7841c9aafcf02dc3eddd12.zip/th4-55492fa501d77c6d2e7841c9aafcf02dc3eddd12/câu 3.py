s = input('nhập chuổi :').upper()
for x in s:
    print(x)
